<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559817633';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559817633,
  'username' => false,
);

$file_sections = array (
  0 => 
  array (
    'type' => 'text',
    'content' => '<h3>Join the Typesetter Community</h3>
		<p>Visit TypesetterCMS.com to access the many <a href="http://www.typesettercms.com/Resources" title="Typesetter Community Resources" rel="nofollow">available resources</a> to help you get the most out of our CMS.</p>
		<ul>
		<li><a href="http://www.typesettercms.com/Themes" title="Typesetter Themes" rel="nofollow">Download Themes</a></li>
		<li><a href="http://www.typesettercms.com/Plugins" title="Typesetter Plugin" rel="nofollow">Download Plugins</a></li>
		<li><a href="http://www.typesettercms.com/Forum" title="Typesetter Forum" rel="nofollow">Get Help in the Forum</a></li>
		<li><a href="http://www.typesettercms.com/Powered_by" title="Sites using Typesetter" rel="nofollow">Show off Your Site</a></li>
		<li><a href="http://www.typesettercms.com/Resources" title="Typesetter Community Resources" rel="nofollow">And Much More...</a></li>
		</ul>
		<p class="sm">(Edit this content by clicking &quot;Edit&quot;, it&#39;s that easy!)</p>',
  ),
);

$meta_data = array (
);