<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559817633';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559817633,
  'username' => false,
);

$file_sections = array (
  0 => 
  array (
    'type' => 'text',
    'content' => '<h2>Contact Us</h2><p>Use the form below to contact us, and be sure to enter a valid email address if you want to hear back from us.</p>',
  ),
);

$meta_data = array (
);