<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559817633';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559817633,
  'username' => false,
);

$file_sections = array (
  0 => 
  array (
    'type' => 'text',
    'content' => '<h3><a href="http://www.typesettercms.com/Our_CMS" title="Features of Our CMS" rel="nofollow">Typesetter Features</a></h3>
		<p>Easy to use True WYSIWYG Editing.</p>
		<p>Flat-file data storage and advanced resource management for fast websites.</p>
		<p>Community driven development</p>
		<p><a href="http://www.typesettercms.com/Our_CMS" title="Features of Our CMS" rel="nofollow">And More...</a></p>
		<p>If you like Typesetter, then you might also like
		<a href="http://lessphp.typesettercms.com" title="A Less to CSS compiler based on the official lesscss project" rel="nofollow">Less.php</a>,
		<a href="http://whatcms.org" title="What CMS? Find out what CMS a site is using" rel="nofollow">WhatCMS.org</a> and
		<a href="http://whichcms.org" title="Which CMS? Find out which CMS has the features you\'re looking for." rel="nofollow">WhichCMS.org</a>.
		</p>',
  ),
);

$meta_data = array (
);