<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559848694';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559848694,
  'username' => 'admin',
);

$users = array (
  'admin' => 
  array (
    'password' => '7e1df8f828a1605f8a1b2b8ed1c427f0b6f4bd3a2195014b1fe2f31c87973324ecf38417a5afd38de6379dc756e5509386fae7548fa4ef862b90d8ee50371ab4',
    'passhash' => 'sha512',
    'granted' => 'all',
    'editing' => 'all',
    'email' => 'mirek.hancl@leg-uelzen.de',
    'file_name' => 'gpsess_ujTWW8TXvlPGM6T8hZZURCRjhpwyelVPOlq1QVDZ.php',
    'attempts' => 0,
    'lastattempt' => 1559848694,
  ),
);

$meta_data = array (
);