<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559821095';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559821095,
  'username' => 'admin',
);

$config = array (
  'language' => 'en',
  'toemail' => 'mirek.hancl@leg-uelzen.de',
  'gpLayout' => 'default',
  'title' => 'T-Race',
  'keywords' => 'Typesetter , Easy CMS, Content Management, PHP, Free CMS, Website builder, Open Source',
  'desc' => 'A new Typesetter installation. You can change your site\'s description in the configuration.',
  'timeoffset' => '0',
  'langeditor' => 'inherit',
  'dateformat' => '%m/%d/%y - %I:%M %p',
  'gpversion' => '5.1.1-b1',
  'passhash' => 'sha512',
  'gpuniq' => 'KO5Nbb4ZoDnOTZZBuykx',
  'combinecss' => true,
  'combinejs' => true,
  'minifyjs' => true,
  'etag_headers' => true,
  'gallery_legacy_style' => false,
  'addons' => 
  array (
    'trace-gadgets' => 
    array (
      'code_folder_part' => '/addons/trace-gadgets',
      'data_folder' => 'trace-gadgets',
      'name' => 'T-Race Gadgets',
      'version' => '1.02',
      'id' => '100',
      'About' => 'Provides all gadgets for T-Race.',
    ),
  ),
  'file_count' => 9,
  'maximgarea' => '2073600',
  'preserve_icc_profiles' => true,
  'preserve_image_metadata' => true,
  'maxthumbsize' => '300',
  'maxthumbheight' => '',
  'check_uploads' => false,
  'colorbox_style' => 'example1',
  'customlang' => 
  array (
  ),
  'showgplink' => false,
  'showsitemap' => false,
  'showlogin' => false,
  'auto_redir' => '90',
  'history_limit' => '30',
  'resize_images' => true,
  'themes' => 
  array (
  ),
  'gadgets' => 
  array (
    'Contact' => 
    array (
      'class' => '\\gp\\special\\ContactGadget',
    ),
    'Search' => 
    array (
      'method' => 
      array (
        0 => '\\gp\\special\\Search',
        1 => 'gadget',
      ),
    ),
    'TRaceGadget_Vouchers' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_Vouchers',
    ),
    'TRaceGadget_PlayerRegistration' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_PlayerRegistration',
    ),
    'TRaceGadget_PlayerLogin' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_PlayerLogin',
    ),
    'TRaceGadget_PlayerStatus' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_PlayerStatus',
    ),
    'TRaceGadget_PlayerResult' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_PlayerResult',
    ),
    'TRaceGadget_Webshop' => 
    array (
      'addon' => 'trace-gadgets',
      'script' => '/addons/trace-gadgets/TRaceGadgets.php',
      'method' => 'TRaceGadget_Webshop',
    ),
  ),
  'hooks' => 
  array (
    'GetHead' => 
    array (
      'trace-gadgets' => 
      array (
        'addon' => 'trace-gadgets',
        'script' => '/addons/trace-gadgets/TRaceGadgets.php',
        'method' => 'add_head_tags',
      ),
    ),
  ),
  'space_char' => '-',
  'cdn' => '',
  'thumbskeepaspect' => false,
  'homepath_auto' => true,
  'homepath_key' => 'a',
  'homepath' => 'Willkommen',
  'admin_links' => 
  array (
  ),
  'HTML_Tidy' => '',
  'Report_Errors' => false,
  'toname' => '',
  'from_address' => 'AutomatedSender@start.t-race',
  'from_name' => 'Automated Sender',
  'from_use_user' => false,
  'require_email' => '',
  'mail_method' => 'mail',
  'sendmail_path' => '',
  'smtp_hosts' => '',
  'smtp_user' => '',
  'smtp_pass' => '',
  'recaptcha_public' => '',
  'recaptcha_private' => '',
  'recaptcha_language' => 'inherit',
);

$meta_data = array (
);