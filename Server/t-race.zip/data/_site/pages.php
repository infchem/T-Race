<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559849510';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559849510,
  'username' => 'admin',
);

$pages = array (
  'gp_menu' => 
  array (
    'a' => 
    array (
      'level' => 0,
    ),
    'c' => 
    array (
      'level' => 0,
    ),
    'g' => 
    array (
      'level' => 0,
    ),
    'h' => 
    array (
      'level' => 0,
    ),
  ),
  'gp_index' => 
  array (
    'Contact' => 'special_contact',
    'Site_Map' => 'special_site_map',
    'Galleries' => 'special_galleries',
    'Missing' => 'special_missing',
    'Search' => 'special_gpsearch',
    'Willkommen' => 'a',
    'Registrierung' => 'c',
    'Login' => 'g',
    'Spiel' => 'h',
    'Ergebnis' => 'i',
  ),
  'gp_titles' => 
  array (
    'a' => 
    array (
      'label' => 'Willkommen',
      'type' => 'image,text,wrapper_section',
    ),
    'special_contact' => 
    array (
      'lang_index' => 'contact',
      'type' => 'special',
    ),
    'special_site_map' => 
    array (
      'lang_index' => 'site_map',
      'type' => 'special',
    ),
    'special_galleries' => 
    array (
      'lang_index' => 'galleries',
      'type' => 'special',
    ),
    'special_missing' => 
    array (
      'label' => 'Missing',
      'type' => 'special',
    ),
    'special_gpsearch' => 
    array (
      'label' => 'Search',
      'type' => 'special',
    ),
    'c' => 
    array (
      'label' => 'Registrierung',
      'type' => 'include',
    ),
    'g' => 
    array (
      'label' => 'Login',
      'type' => 'include',
    ),
    'h' => 
    array (
      'label' => 'Spiel',
      'type' => 'include',
    ),
    'i' => 
    array (
      'label' => 'Ergebnis',
      'type' => 'include',
    ),
  ),
  'gpLayouts' => 
  array (
    'default' => 
    array (
      'theme' => 'Bootswatch_Scss/Flatly',
      'label' => 'Bootswatch_Scss/Flatly',
      'color' => '#93c47d',
      'doctype' => '',
      'all_gadgets' => false,
      'template_mod' => 1546479515,
    ),
  ),
);

$meta_data = array (
);