<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559818544';
$file_stats = array (
  'created' => 1559818419,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559818544,
  'username' => 'admin',
);

$file_sections = array (
  0 => 
  array (
    'type' => 'include',
    'content' => 'TRaceGadget_PlayerStatus',
    'attributes' => 
    array (
    ),
    'include_type' => 'gadget',
    'modified' => 1559818526,
    'modified_by' => 'admin',
    'gp_label' => 'File Include',
  ),
  1 => 
  array (
    'type' => 'include',
    'content' => 'TRaceGadget_Vouchers',
    'attributes' => 
    array (
    ),
    'include_type' => 'gadget',
    'modified' => 1559818532,
    'modified_by' => 'admin',
    'gp_label' => 'File Include',
  ),
  2 => 
  array (
    'type' => 'include',
    'content' => 'TRaceGadget_Webshop',
    'attributes' => 
    array (
      'class' => '',
    ),
    'gp_label' => 'File Include',
    'include_type' => 'gadget',
    'modified' => 1559818542,
    'modified_by' => 'admin',
  ),
);

$meta_data = array (
  'file_number' => 8,
  'file_type' => 'include',
);