<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559849510';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559849510,
  'username' => 'admin',
);

$file_sections = array (
  0 => 
  array (
    'type' => 'wrapper_section',
    'content' => '',
    'contains_sections' => '2',
    'attributes' => 
    array (
      'class' => 'gpRow',
    ),
    'gp_label' => 'Section Wrapper',
    'gp_color' => '#555',
  ),
  1 => 
  array (
    'type' => 'text',
    'content' => '<div>
<h2>Willkommen bei T-Race</h2>

<p>T-Race ist ein&nbsp;rasantes Spiel zum Thema Datenspuren. Du verwendest gerade vermutlich Dein eigenes Smartphone. Was Du noch benötigst, ist eine T-Race Spielkarte und ein Benutzerkonto. Klicke oben im Menü auf Registrierung&nbsp;und trage Deine persönlichen Daten ein. Anschließend kannst Du Dich einloggen und los spielen!</p>

<p>&nbsp;</p>

<p>Viel Spaß&nbsp;<img alt="smiley" height="22" src="/include/thirdparty/ckeditor_34/plugins/smiley/images/regular_smile.png" title="smiley" width="22" /></p>
</div>
',
    'attributes' => 
    array (
      'class' => 'gpCol-6',
    ),
    'gp_label' => 'Editable Text',
    'resized_imgs' => 
    array (
    ),
    'modified' => 1559849509,
    'modified_by' => 'admin',
  ),
  2 => 
  array (
    'type' => 'image',
    'content' => '',
    'nodeName' => 'img',
    'attributes' => 
    array (
      'src' => '/data/_resized/img_type/Titel.jpg.1559848718.png',
      'alt' => 'T-Race Logo',
      'width' => '400',
      'height' => '230',
      'class' => 'gpCol-6',
    ),
    'gp_label' => 'Image',
    'orig_src' => '/data/_uploaded/image/Titel.jpg',
    'posx' => '-252',
    'posy' => '-17',
    'modified' => 1559849050,
    'modified_by' => 'admin',
  ),
);

$meta_data = array (
  'file_number' => 1,
  'file_type' => 'text',
  'gallery_dir' => '/image',
);