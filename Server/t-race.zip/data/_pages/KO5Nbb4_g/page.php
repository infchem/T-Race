<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559818514';
$file_stats = array (
  'created' => 1559818409,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559818514,
  'username' => 'admin',
);

$file_sections = array (
  0 => 
  array (
    'type' => 'include',
    'content' => 'TRaceGadget_PlayerLogin',
    'gp_label' => 'File Include',
    'attributes' => 
    array (
      'class' => '',
    ),
    'include_type' => 'gadget',
    'modified' => 1559818512,
    'modified_by' => 'admin',
  ),
);

$meta_data = array (
  'file_number' => 7,
  'file_type' => 'include',
);