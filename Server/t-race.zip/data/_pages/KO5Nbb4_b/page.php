<?php
defined('is_running') or die('Not an entry point...');
$fileVersion = '5.1.1-b1';
$fileModTime = '1559817633';
$file_stats = array (
  'created' => 1559817633,
  'gpversion' => '5.1.1-b1',
  'modified' => 1559817633,
  'username' => false,
);

$file_sections = array (
  0 => 
  array (
    'type' => 'text',
    'content' => '<h1>A Heading Page</h1>
		<li><a href="$linkPrefix/Child_Page">Child Page</a></li>
		</ul>',
  ),
);

$meta_data = array (
  'file_number' => 2,
  'file_type' => 'text',
);